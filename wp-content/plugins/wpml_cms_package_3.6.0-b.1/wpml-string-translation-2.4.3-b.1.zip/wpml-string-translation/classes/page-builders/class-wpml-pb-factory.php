<?php

class WPML_PB_Factory {

	private $wpdb;
	private $sitepress;

	private $string_translations = null;
	private $register_shortcodes = null;
	private $shortcodes = array();

	public function __construct( $wpdb, $sitepress ) {
		$this->wpdb      = $wpdb;
		$this->sitepress = $sitepress;
	}

	public function add_shortcodes( $shortcode_data ) {
		foreach ( $shortcode_data as $shortcode ) {
			$tag = $shortcode['tag']['value'];
			if ( ! in_array( $tag, $this->shortcodes ) ) {
				$this->shortcodes[ $tag ] = array(
					'encoding' => $shortcode['tag']['encoding'],
					'attributes' => array(),
				);
			}
			if ( isset( $shortcode['attributes'] ) ) {
				foreach ( $shortcode['attributes'] as $attribute ) {
					$this->shortcodes[ $tag ]['attributes'][ $attribute['value'] ] = $attribute['encoding'];
				}
			}
		}
	}

	public function get_shortcodes() {
		return array_keys( $this->shortcodes );
	}

	public function get_shortcode_attributes( $tag ) {
		return array_keys( $this->shortcodes[ $tag ]['attributes'] );
	}

	public function get_shortcode_tag_encoding( $tag ) {
		return $this->shortcodes[ $tag ]['encoding'];
	}

	public function get_shortcode_attribute_encoding( $tag, $attribute ) {
		return $this->shortcodes[ $tag ]['attributes'][ $attribute ];
	}

	public function get_wpml_package( $package_id ) {
		return new WPML_Package( $package_id );
	}

	public function get_string_translations() {
		if ( ! $this->string_translations ) {
			$this->string_translations = new WPML_PB_String_Translation( $this->wpdb, $this );
		}

		return $this->string_translations;
	}

	public function get_shortcode_parser() {
		return new WPML_PB_Shortcodes( $this );
	}

	public function get_register_shortcodes() {
		if ( ! $this->register_shortcodes ) {
			$this->register_shortcodes = new WPML_PB_Register_Shortcodes( $this->sitepress, new WPML_PB_String_Registration( $this ), $this );
		}

		return $this->register_shortcodes;
	}

	public function get_update_post( $package_data ) {
		return new WPML_PB_Update_Post( $this->wpdb, $this->sitepress, $package_data, $this );
	}

	public function get_package_key( $page_id ) {
		return array(
			'kind'    => $this->get_package_kind(),
			'name'    => $page_id,
			'title'   => 'Page Builder Page ' . $page_id,
			'post_id' => $page_id,
		);
	}

	public function get_package_kind() {
		return 'Page Builder ShortCode Strings';
	}

	public function get_content_updater() {
		return new WPML_PB_Update_Shortcodes_In_Content( $this );
	}

	public function get_update_translated_posts_from_original() {
		return new WPML_PB_Update_Translated_Posts_From_Original( $this->sitepress, $this );
	}

}
