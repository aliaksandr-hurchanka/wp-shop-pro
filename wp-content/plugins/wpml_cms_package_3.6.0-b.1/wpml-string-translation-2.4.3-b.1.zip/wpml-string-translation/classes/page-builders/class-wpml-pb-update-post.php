<?php

class WPML_PB_Update_Post {

	private $package_data;
	/** @var  WPML_PB_Factory $factory */
	private $factory;
	/** @var  wpdb $wpdb */
	private $wpdb;
	/** @var  SitePress $sitepress */
	private $sitepress;

	public function __construct( $wpdb, $sitepress, $package_data, $factory ) {
		$this->wpdb         = $wpdb;
		$this->sitepress    = $sitepress;
		$this->package_data = $package_data;
		$this->factory      = $factory;
	}

	public function update() {

		$package           = $this->package_data['package'];
		$original_post_id  = $package->post_id;
		$post              = get_post( $original_post_id );
		$element_type      = 'post_' . $post->post_type;
		$trid              = $this->sitepress->get_element_trid( $original_post_id, $element_type );
		$post_translations = $this->sitepress->get_element_translations( $trid, $element_type );

		$languages = $this->package_data['languages'];

		$string_translations = $package->get_translated_strings( array() );

		foreach ( $languages as $lang ) {
			if ( isset( $post_translations[ $lang ] ) ) {
				$this->update_post( $post_translations[ $lang ]->element_id, $post->post_content, $string_translations, $lang );
			}
		}
	}

	private function update_post( $post_id, $original_content, $string_translations, $lang ) {
		$content_updater = $this->factory->get_content_updater();
		$new_content     = $content_updater->update( $original_content, $string_translations, $lang );

		if ( $new_content != $original_content ) {
			wp_update_post( array(
				'ID'           => $post_id,
				'post_content' => $new_content,
			) );
		}
	}

}