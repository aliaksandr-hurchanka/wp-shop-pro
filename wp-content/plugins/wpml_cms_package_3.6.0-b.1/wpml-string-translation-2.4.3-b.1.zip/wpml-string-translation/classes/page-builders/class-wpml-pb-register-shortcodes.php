<?php

/**
 * Class WPML_PB_Register_Shortcodes
 */
class WPML_PB_Register_Shortcodes {

	private $handle_strings;
	/** @var  WPML_PB_Factory $factory */
	private $factory;
	/** @var  SitePress $sitepress */
	private $sitepress;

	/**
	 * WPML_Add_Wrapper_Shortcodes constructor.
	 *
	 * @param SitePress $sitepress
	 * @param WPML_PB_String_Registration $handle_strings
	 */
	public function __construct( SitePress $sitepress, WPML_PB_String_Registration $handle_strings, WPML_PB_Factory $factory ) {
		$this->sitepress      = $sitepress;
		$this->handle_strings = $handle_strings;
		$this->factory        = $factory;
	}

	public function register_shortcode_strings( $post_id, $content ) {
		$shortcode_parser = $this->factory->get_shortcode_parser();
		$shortcodes       = $shortcode_parser->get_shortcodes( $content );

		foreach ( $shortcodes as $shortcode ) {
			$shortcode_content = $shortcode['content'];
			$encoding          = $this->factory->get_shortcode_tag_encoding( $shortcode['tag'] );
			$shortcode_content = $this->decode( $shortcode_content, $encoding );
			$this->handle_strings->register_shortcode_string( $post_id, $shortcode_content, 'VISUAL' );

			$attributes              = (array) shortcode_parse_atts( $shortcode['attributes'] );
			$translatable_attributes = $this->factory->get_shortcode_attributes( $shortcode['tag'] );
			if ( ! empty( $attributes ) ) {
				foreach ( $attributes as $attr => $attr_value ) {
					if ( in_array( $attr, $translatable_attributes ) ) {
						$encoding   = $this->factory->get_shortcode_attribute_encoding( $shortcode['tag'], $attr );
						$attr_value = $this->decode( $attr_value, $encoding );
						$this->handle_strings->register_shortcode_string( $post_id, $attr_value, 'LINE' );
					}
				}
			}
		}
	}

	private function decode( $string, $encoding ) {
		switch ( $encoding ) {
			case 'base64':
				$string = rawurldecode( base64_decode( strip_tags( $string ) ) );
				break;
		}

		return $string;
	}
}
