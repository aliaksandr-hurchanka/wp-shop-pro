<?php

/**
 * Class WPML_PB_String_Translation
 */
class WPML_PB_String_Translation {

	/** @var  wpdb $wpdb */
	private $wpdb;
	/** @var  WPML_PB_Factory $factory */
	private $factory;

	/** @var array $packages_to_update */
	private $packages_to_update = array();

	public function __construct( wpdb $wpdb, WPML_PB_Factory $factory ) {
		$this->wpdb    = $wpdb;
		$this->factory = $factory;
	}

	public function new_translation( $translated_string_id ) {
		list( $package_id, $string_id, $language ) = $this->get_package_for_translated_string( $translated_string_id );
		if ( $package_id ) {
			$package = $this->factory->get_wpml_package( $package_id );
			if ( $this->factory->get_package_kind() === $package->kind ) {
				$this->add_package_to_update_list( $package, $language );
				if ( DEFINED( 'DOING_AJAX' ) && DOING_AJAX ) {
					$this->save_translations_to_post();
				}
			}
		}
	}

	public function save_translations_to_post() {
		foreach ( $this->packages_to_update as $package_data ) {
			$update_post = $this->factory->get_update_post( $package_data );
			$update_post->update();
		}
	}

	private function get_package_for_translated_string( $translated_string_id ) {
		$sql    = $this->wpdb->prepare(
			"SELECT s.string_package_id, s.id, t.language
			FROM {$this->wpdb->prefix}icl_strings s 
			LEFT JOIN {$this->wpdb->prefix}icl_string_translations t 
			ON s.id = t.string_id 
			WHERE t.id = %d", $translated_string_id );
		$result = $this->wpdb->get_row( $sql );

		if ( $result ) {
			return array( $result->string_package_id, $result->id, $result->language );
		} else {
			return array( null, null, null );
		}
	}

	private function add_package_to_update_list( $package, $language ) {
		if ( ! isset( $this->packages_to_update[ $package->ID ] ) ) {
			$this->packages_to_update[ $package->ID ] = array( 'package'   => $package,
			                                                   'languages' => array( $language )
			);
		} else {
			if ( ! in_array( $language, $this->packages_to_update[ $package->ID ]['languages'] ) ) {
				$this->packages_to_update[ $package->ID ]['languages'][] = $language;
			}
		}
	}

}
