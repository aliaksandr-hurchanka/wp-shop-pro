<?php

class WPML_PB_Shortcodes {

	/** @var  WPML_PB_Factory $factory */
	private $factory;


	public function __construct( WPML_PB_Factory $factory ) {
		$this->factory = $factory;
	}

	public function get_shortcodes( $content ) {

		$shortcodes = array();
		$pattern    = get_shortcode_regex( $this->factory->get_shortcodes() );

		if ( preg_match_all( '/' . $pattern . '/s', $content, $matches ) && isset( $matches[5] ) && ! empty( $matches[5] ) ) {
			for ( $index = 0; $index < sizeof( $matches[0] ); $index ++ ) {

				$shortcodes[] = array(
					'block'      => $matches[0][ $index ],
					'tag'        => $matches[2][ $index ],
					'attributes' => $matches[3][ $index ],
					'content'    => $matches[5][ $index ],
				);
			}
		}

		return $shortcodes;
	}
}
