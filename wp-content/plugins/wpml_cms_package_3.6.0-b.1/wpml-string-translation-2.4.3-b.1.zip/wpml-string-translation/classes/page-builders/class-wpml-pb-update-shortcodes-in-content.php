<?php

class WPML_PB_Update_Shortcodes_In_Content {

	/** @var  WPML_PB_Factory $factory */
	private $factory;

	private $new_content;
	private $string_translations;
	private $lang;

	public function __construct( WPML_PB_Factory $factory ) {
		$this->factory = $factory;
	}

	public function update( $original_content, $string_translations, $lang ) {
		$this->new_content         = $original_content;
		$this->string_translations = $string_translations;
		$this->lang                = $lang;

		$shortcode_parser = $this->factory->get_shortcode_parser();
		$shortcodes       = $shortcode_parser->get_shortcodes( $original_content );

		foreach ( $shortcodes as $shortcode ) {
			$this->update_shortcodes( $shortcode );
			$this->update_shortcode_attributes( $shortcode );
		}

		return $this->new_content;
	}

	private function update_shortcodes( $shortcode_data ) {
		$encoding = $this->factory->get_shortcode_tag_encoding( $shortcode_data['tag'] );
		$this->replace_string_with_translation( $shortcode_data['block'], $shortcode_data['content'], $encoding );
	}

	private function update_shortcode_attributes( $shortcode_data ) {

		$shortcode_attribute = $shortcode_data['attributes'];

		$attributes              = (array) shortcode_parse_atts( $shortcode_attribute );
		$translatable_attributes = $this->factory->get_shortcode_attributes( $shortcode_data['tag'] );
		if ( ! empty( $attributes ) ) {
			foreach ( $attributes as $attr => $attr_value ) {
				if ( in_array( $attr, $translatable_attributes ) ) {
					$encoding            = $this->factory->get_shortcode_attribute_encoding( $shortcode_data['tag'], $attr );
					$shortcode_attribute = $this->replace_string_with_translation( $shortcode_attribute, $attr_value, $encoding );
				}
			}
		}
	}

	private function replace_string_with_translation( $block, $original, $encoding = false ) {
		$decoded_original = $original;
		$decoded_original = $this->decode( $decoded_original, $encoding );
		$translation      = $this->get_translation( $decoded_original );
		$new_block        = $block;
		if ( $translation ) {
			$translation       = $this->encode( $translation, $encoding );
			$new_block         = str_replace( $original, $translation, $block );
			$this->new_content = str_replace( $block, $new_block, $this->new_content );
		}

		return $new_block;
	}

	private function get_translation( $original ) {
		$translation = null;
		$string_name = md5( $original );
		if ( isset( $this->string_translations[ $string_name ][ $this->lang ] ) && $this->string_translations[ $string_name ][ $this->lang ]['status'] == ICL_TM_COMPLETE ) {
			$translation = $this->string_translations[ $string_name ][ $this->lang ]['value'];
		}

		return $translation;
	}

	private function decode( $string, $encoding ) {
		switch ( $encoding ) {
			case 'base64':
				$string = rawurldecode( base64_decode( strip_tags( $string ) ) );
				break;
		}

		return $string;
	}

	private function encode( $string, $encoding ) {
		switch ( $encoding ) {
			case 'base64':
				$string = base64_encode( $string );
				break;
		}

		return $string;
	}

}
