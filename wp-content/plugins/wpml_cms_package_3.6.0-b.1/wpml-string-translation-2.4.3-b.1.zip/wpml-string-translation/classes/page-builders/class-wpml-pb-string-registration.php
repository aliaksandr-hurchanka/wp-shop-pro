<?php

/**
 * Class WPML_PB_String_Registration
 */
class WPML_PB_String_Registration {

	private $factory;

	public function __construct( WPML_PB_Factory $factory ) {
		$this->factory = $factory;
	}

	/**
	 * @param string $shortcode_content
	 * @param string $type
	 */
	public function register_shortcode_string( $post_id, $shortcode_content = '', $type = 'LINE' ) {
		if ( $shortcode_content ) {
			do_action(
				'wpml_register_string',
				$shortcode_content,
				md5( $shortcode_content ),
				$this->factory->get_package_key( $post_id ),
				$shortcode_content,
				$type
			);
		}
	}

}
