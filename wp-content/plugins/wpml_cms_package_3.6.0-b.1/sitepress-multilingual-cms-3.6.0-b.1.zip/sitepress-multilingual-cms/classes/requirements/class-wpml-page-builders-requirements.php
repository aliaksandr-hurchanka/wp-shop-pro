<?php

/**
 * @author OnTheGo Systems
 */
class WPML_Page_Builders_Requirements {
	const NOTICE_GROUP = 'requirements';
	const NOTICE_ID    = 'missing-requirements';

	private $issues = array();

	/**
	 * Page_Builders_Requirements constructor.
	 *
	 * @param SitePress $sitepress
	 */
	public function __construct( SitePress $sitepress ) {
		$this->sitepress = $sitepress;
	}

	public function init_hooks() {
		if ( $this->sitepress->get_setting( 'setup_complete' ) ) {
			add_action( 'admin_init', array( $this, 'init' ) );
		}
	}

	public function init() {
		if ( $this->sitepress->get_wp_api()->is_core_page() ) {
			$this->update_issues();
			$this->update_notices();
		}
	}

	private function update_notices() {
		$wpml_admin_notices = wpml_get_admin_notices();
		if ( $this->issues ) {
			$template_paths   = array(
				ICL_PLUGIN_PATH . '/templates/warnings/',
			);
			$twig_loader      = new Twig_Loader_Filesystem( $template_paths );
			$environment_args = array();
			if ( WP_DEBUG ) {
				$environment_args['debug'] = true;
			}
			$twig         = new Twig_Environment( $twig_loader, $environment_args );
			$twig_service = new WPML_Twig_Template( $twig );

			$requirements_notice = new WPML_Requirements_Notification( $twig_service );

			$warning = $requirements_notice->get( $this->issues, 1 );

			if ( $warning ) {
				$notice = new WPML_Notice( SELF::NOTICE_ID, $warning, SELF::NOTICE_GROUP );
				$wp_api = $this->sitepress->get_wp_api();
				$notice->add_display_callback( array( $wp_api, 'is_core_page' ) );

				$dismiss_action = new WPML_Notice_Action( __( 'Dismiss', 'sitepress' ), '#', true, false, true );
				$notice->add_action( $dismiss_action );
				$document_action = new WPML_Notice_Action( __( 'How to translate pages built with Visual Composer', 'sitepress' ), 'https://wpml.org' );
				$notice->add_action( $document_action );

				$wpml_admin_notices->add_notice( $notice, true );
			} else {
				$wpml_admin_notices->remove_notice( SELF::NOTICE_GROUP, SELF::NOTICE_ID );
			}
		} else {
			$wpml_admin_notices->remove_notice( SELF::NOTICE_GROUP, SELF::NOTICE_ID );
		}
	}

	private function update_issues() {
		$page_builders = new WPML_Page_Builders( $this->sitepress->get_wp_api() );
		$requirements  = new WPML_Requirements();
		$tpd           = new WPML_Third_Party_Dependencies( $page_builders, $requirements );

		$this->issues = $tpd->get_issues();
	}
}
