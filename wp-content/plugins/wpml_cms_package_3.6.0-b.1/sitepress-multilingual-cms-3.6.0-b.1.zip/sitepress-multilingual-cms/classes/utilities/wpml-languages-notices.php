<?php

class WPML_Languages_Notices {

	function maybe_create_notice_missing_menu_items( $languages_count ) {
		global $wpml_admin_notices;

		if( 1 === $languages_count ) {
			$text = __( 'You need to configure at least one more language in order to access "Theme and plugins localization" and "Media translation".', 'sitepress' );
			$notice = new WPML_Notice( 'wpml-missing-menu-items', $text, 'wpml-core' );
			$notice->set_css_class_types( 'info' );
			$notice->set_dismissible( true );
			$wpml_admin_notices->add_notice( $notice );
		} else {
			$wpml_admin_notices->remove_notice( 'wpml-core', 'wpml-missing-menu-items' );
		}
	}
}