<?php

class WPML_WP_Stylesheet_URI {

	private $sitepress;

	function __construct( $sitepress ) {
		$this->sitepress = $sitepress;
	}


	function fix_stylesheet_uri(){
		if( (string) $this->sitepress->get_setting( 'language_negotiation_type' ) === (string) WPML_LANGUAGE_NEGOTIATION_TYPE_DOMAIN ){
			add_filter( 'stylesheet_uri', array( $this, 'stylesheet_uri_callback' ), 10, 2 );
		}
	}

	/**
	 * @param $uri
	 *
	 * @return mixed|void
	 */
	function stylesheet_uri_callback( $uri, $dir ){
		$parsed_url = wpml_parse_url( $uri );
		if( is_array( $parsed_url ) ){
			if( isset( $parsed_url['host'] ) && $_SERVER['HTTP_HOST'] ){
				$stylesheet_uri = str_replace( $parsed_url['host'], $_SERVER['HTTP_HOST'], $uri );
			} else {
				$stylesheet_uri = $uri;
			}
		}else{
			$stylesheet_uri = $uri;
		}

		return $stylesheet_uri;
	}
}