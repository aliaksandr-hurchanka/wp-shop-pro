<?php

class WPML_WP_Option_Filter {
	private $sitepress;

	function __construct( $sitepress ) {
		$this->sitepress = $sitepress;

		$this->fix_siteurl_domain();
	}


	function fix_siteurl_domain(){
		if( WPML_LANGUAGE_NEGOTIATION_TYPE_DOMAIN === (int) $this->sitepress->get_setting( 'language_negotiation_type' ) ){
			add_filter( 'option_siteurl', array( $this, 'siteurl_callback' ), 10, 2 );
		}
	}

	/**
	 * @param $siteurl
	 *
	 * @return mixed
	 */
	function siteurl_callback( $siteurl ){
		$parsed_url = wpml_parse_url( $siteurl );
		$host = is_array( $parsed_url ) && isset( $parsed_url['host'] );
		if( $host && isset( $_SERVER['HTTP_HOST'] ) ){
			$siteurl = str_replace( $parsed_url['host'], $_SERVER['HTTP_HOST'], $siteurl );
		}

		return $siteurl;
	}
}