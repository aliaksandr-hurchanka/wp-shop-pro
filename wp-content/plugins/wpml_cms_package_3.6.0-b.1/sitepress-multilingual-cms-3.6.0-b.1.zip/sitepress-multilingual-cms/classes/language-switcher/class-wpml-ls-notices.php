<?php

class WPML_LS_Notices {

	const GROUP = 'wpml-ls-notices';
	const BACKWARDS_COMPATIBILITY = 'backwards-compatibility';

	/* @var WPML_Notices $admin_notices */
	private $admin_notices;

	/**
	 * WPML_LS_Notices constructor.
	 *
	 * @param WPML_Notices $admin_notices
	 */
	public function __construct( WPML_Notices $admin_notices = null ) {
		$this->admin_notices = $admin_notices ? $admin_notices : wpml_get_admin_notices();
	}

	public function add_backwards_compatibility() {
		$action_url = WPML_LS_Admin_UI::get_page_url( 'wpml_skip_ls_backwards_compatibility=1' );
		$text = '<p>' . esc_html__( "This WPML version uses a new language switcher with new CSS classes. If you don't have any custom CSS, it's recommended to skip backwards compatibility." , 'sitepress' ) . '</p>';
		$text .= '<p><a href="' . $action_url . '" class="button-secondary">' . esc_html__( "Skip language switcher backwards compatibility" , 'sitepress' ) . '</a></p>';
		$notice = new WPML_Notice( self::BACKWARDS_COMPATIBILITY, $text, self::GROUP );
		$notice->set_restrict_to_pages( array( WPML_LS_Admin_UI::PAGE_HOOK ) );
		$notice->set_css_class_types( 'info' );
		$notice->set_dismissible( true );
		$this->admin_notices->add_notice( $notice );
	}

	public function remove_backwards_compatibility() {
		$this->admin_notices->remove_notice( self::GROUP, self::BACKWARDS_COMPATIBILITY );
	}
}